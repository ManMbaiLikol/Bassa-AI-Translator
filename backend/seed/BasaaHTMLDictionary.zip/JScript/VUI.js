// VUI.js - JavaScript code for the lexical data browser's visual user interface
// For Shoebox test version 4.11

function sPrimary(sWord)
{
    var s = "";
	for ( var i = 0; i != sWord.length; i++ )
		{
		var ch = sWord.charAt(i);
	    ch = ch.toLowerCase();
		var bPrimary = (
			("a" <= ch && ch <= "z") ||
			("0" <= ch && ch <= "9") ||  // Homonym number
			ch == " "
			);
		if ( bPrimary )
			s += ch;
		}

    return s;
}

function sFirstLetter(sWord)
{
	var sLetter = "";
	var s = sPrimary(sWord);
    if ( s.length == 0 )
        return sLetter;

	sLetter = s.charAt(0);

	// 1998-11-20 MRP: Special code for multigraphs ng and ny
//	if ( sLetter == "n" && 1 < s.length )
//		{
//		var sNext = s.charAt(1);
//		if ( sNext == "g" || sNext == "y" )
//			sLetter += sNext;
//		}
		
	return sLetter;
}

function sFirstLetterFromPathname(sPathname)
{
	var s = "";
	var i = sPathname.lastIndexOf("/");
	var iBackslash = sPathname.lastIndexOf("\\");
	if ( i < iBackslash )
		i = iBackslash;
	if ( i < 0 || i == sPathname.length - 1 )
		return s;

	s = sPathname.substring(i + 1, sPathname.length);

	i = s.indexOf(".");
	if ( 0 < i )
		s = s.substring(0, i);
	
	s = sPrimary(s);
	s = sFirstLetter(s);
	
	return s;
}

function search(sWord, sFrame, bSeparateLetterPages)
{
	var docFrame = window.parent.frames[sFrame].document;

	if ( bSeparateLetterPages )
		{
		var sLetterSearch = sFirstLetter(sWord);
		if ( sLetterSearch.length == 0 )
			return true;
			
		var sPathname = docFrame.location.pathname;
		var sLetterFrame = sFirstLetterFromPathname(sPathname);
		if ( sLetterSearch != sLetterFrame )
			{
			var sFile = sLetterSearch + ".html";
		    docFrame.location.href = sFile;
			return true;
			}
		}

    sWord = sPrimary(sWord);
    var lenWord = sWord.length;
    
	var a = docFrame.anchors;
	var n = a.length;
	for ( var i = 0; i != n; i++ )
		{
		var sAnchor = sPrimary(a[i].name);
		var lenAnchor = sAnchor.length;
		var bMatch = false;
		if ( lenWord == lenAnchor && sWord == sAnchor )
			bMatch = true;
		else if ( lenWord < lenAnchor && sWord == sAnchor.substring(0, lenWord) )
			bMatch = true;
		if ( bMatch )
			{
		    docFrame.location.hash = a[i].name;
		    break;
		    }
		}
	
	return true;
}

function upper_folder(s)
{
    document.location.href = "../" + s + "/index.html";
}

function lower_page(s)
{
    window.parent.frames["index"].document.location.href = s + ".html";
}
